=================
collabora-release
=================

This is the NethServer Collabora repository installer.
